import React from 'react'
import MessageInput from '../components/styling/MessageInput.js'

const Text = () => {

//   const [text,setText]=useState("")

//   const handleSubmit=async (e) =>{
//     e.preventDefault();

//     const payload = {
//       text,
//     };
//     try{
//       const responce= await axios.post("'http://127.0.0.1:8000/api/text/'", payload);
//       console.log("submitted text",responce.data)
//     }
//    catch (error) {
//     console.error('There was an error!', error);
//     console.error('Error Response:', error.response);
//     setMessages(['Invalid text']);
// }

//   };
  return (
    <div>
         <MessageInput />


    </div>
  )
}

export default Text
