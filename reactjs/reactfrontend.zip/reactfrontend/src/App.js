import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Main from './Main';
import BuildQuiz from './components/BuildQuiz';
import BuildTrueFalseQuiz from './components/BuildTrueFalseQuiz';
import BuildQAQuiz from './components/BuildQAQuiz';  
import SubjectQuiz from './components/SubjectQuiz';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/BuildQuiz" element={<BuildQuiz />} />
        <Route path="/BuildTrueFalseQuiz" element={<BuildTrueFalseQuiz />} />
        <Route path="/BuildQAQuiz" element={<BuildQAQuiz />} />  {/* Add route */}
        {/* Other routes can be added here */}
      </Routes>
      <Main />
    </Router>
  );
}

export default App;