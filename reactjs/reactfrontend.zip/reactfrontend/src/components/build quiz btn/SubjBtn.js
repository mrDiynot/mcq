import '../build quiz btn/BtnSubj.css';

function BtnSubject() {
  return (
    <div>
      <button className="build-quiz-btn">
        Build Quiz
      </button>
    </div>
  );
}

export default BtnSubject;