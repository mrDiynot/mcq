import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaEdit, FaTrash } from 'react-icons/fa';
import EditModal from './EditModal';
import AddQuestionModal from './AddQuestionModal';
import EditTrueFalseModal from './EditTrueFalseModal';
import AddTrueFalseModal from './AddTrueFalseModal';
import './buildstyle.css';

function BuildQuiz() {
  const [questions, setQuestions] = useState([]);
  const [tfQuestions, setTFQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [isQuizActive, setIsQuizActive] = useState(false);
  const [remainingTime, setRemainingTime] = useState(0);
  const [startTime, setStartTime] = useState(null);
  const [isAddQuestionModalOpen, setIsAddQuestionModalOpen] = useState(false);
  const [isAddTFModalOpen, setIsAddTFModalOpen] = useState(false);
  const [questionType, setQuestionType] = useState('MCQ');

  useEffect(() => {
    axios
      .get('http://localhost:8000/api/mcq-questions/')
      .then((response) => {
        setQuestions(response.data || []);
        setLoading(false);
      })
      .catch((error) => {
        setError('There was an error fetching the questions!');
        setLoading(false);
      });

    axios
      .get('http://localhost:8000/api/true-false-questions/')
      .then((response) => {
        setTFQuestions(response.data || []);
        setLoading(false);
      })
      .catch((error) => {
        setError('There was an error fetching the True/False questions!');
        setLoading(false);
      });
  }, []);

  const handleStartQuiz = () => {
    setIsQuizActive(true);
    setStartTime(Date.now());
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleEdit = (questionId, type) => {
    if (type === 'MCQ') {
      const question = questions.find((q) => q.id === questionId);
      setSelectedQuestion(question);
      setIsModalOpen(true);
    } else {
      const question = tfQuestions.find((q) => q.id === questionId);
      setSelectedQuestion(question);
      setIsModalOpen(true);
    }
  };

  const handleSave = (updatedQuestion, type) => {
    if (type === 'MCQ') {
      axios
        .put(`http://localhost:8000/api/mcq-questions/${updatedQuestion.id}/`, updatedQuestion)
        .then((response) => {
          setQuestions((prevQuestions) =>
            prevQuestions.map((q) => (q.id === response.data.id ? response.data : q))
          );
          alert('MCQ updated successfully!');
          setIsModalOpen(false);
        })
        .catch((error) => {
          console.error('Error updating MCQ:', error.response.data);
          alert('There was an error updating the MCQ.');
        });
    } else {
      axios
        .put(`http://localhost:8000/api/true-false-questions/${updatedQuestion.id}/`, updatedQuestion)
        .then((response) => {
          setTFQuestions((prevQuestions) =>
            prevQuestions.map((q) => (q.id === response.data.id ? response.data : q))
          );
          alert('True/False Question updated successfully!');
          setIsModalOpen(false);
        })
        .catch((error) => {
          console.error('Error updating True/False question:', error.response.data);
          alert('There was an error updating the True/False question.');
        });
    }
  };

  const handleDelete = (questionId, type) => {
    if (type === 'MCQ') {
      axios
        .delete(`http://localhost:8000/api/mcq-questions/${questionId}/`)
        .then(() => {
          setQuestions((prevQuestions) =>
            prevQuestions.filter((q) => q.id !== questionId)
          );
          alert('MCQ deleted successfully!');
        })
        .catch((error) => {
          console.error('Error deleting MCQ:', error.response.data);
          alert('There was an error deleting the MCQ.');
        });
    } else {
      axios
        .delete(`http://localhost:8000/api/true-false-questions/${questionId}/`)
        .then(() => {
          setTFQuestions((prevQuestions) =>
            prevQuestions.filter((q) => q.id !== questionId)
          );
          alert('True/False Question deleted successfully!');
        })
        .catch((error) => {
          console.error('Error deleting True/False question:', error.response.data);
          alert('There was an error deleting the True/False question.');
        });
    }
  };

  const handleAddQuestion = (newQuestion, type) => {
    if (type === 'MCQ') {
      axios
        .post('http://localhost:8000/api/mcq-questions/', newQuestion)
        .then((response) => {
          setQuestions((prevQuestions) => [...prevQuestions, response.data]);
          alert('MCQ added successfully!');
        })
        .catch((error) => {
          console.error('Error adding MCQ:', error.response.data);
          alert('There was an error adding the MCQ.');
        });
    } else {
      axios
        .post('http://localhost:8000/api/true-false-questions/', newQuestion)
        .then((response) => {
          setTFQuestions((prevQuestions) => [...prevQuestions, response.data]);
          alert('True/False Question added successfully!');
        })
        .catch((error) => {
          console.error('Error adding True/False question:', error.response.data);
          alert('There was an error adding the True/False question.');
        });
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className="build-quiz-container">
      <div className="sidebar">
        <h3>Recent Quiz</h3>
        <ul className="quiz-list">
          <li onClick={() => setQuestionType('MCQ')}>MCQs</li>
          <li onClick={() => setQuestionType('TrueFalse')}>True/False</li>
        </ul>
        <button className="show-more-btn">Show More</button>
        <div className="my-quizzes">
          <a href="#">My Quizzes</a>
          <a href="#">My Quizzes</a>
        </div>
      </div>
      <div className="main-content">
        <h2>Build Quiz</h2>
        <div className="header">
          <h3 className="quiz-title">Title of Quiz</h3>
          {!isQuizActive && (
            <button className="btn btn-primary start-quiz-btn" onClick={handleStartQuiz}>
              Start Quiz
            </button>
          )}
        </div>
        {isQuizActive && (
          <div className="timer">
            <h3>Time Remaining: {formatTime(remainingTime)}</h3>
          </div>
        )}
        {questionType === 'MCQ' && (
          <div className="mcq-section">
            <div className="mcq-header">
              <h2>MCQs</h2>
            </div>
            <div className="mcq-content">
              {questions.map((question, index) => (
                <div className="mcq-card" key={question.id}>
                  <div className="card-header">
                    <h5>{index + 1}</h5>
                  </div>
                  <div className="card-body">
                    <div className="question-header">
                      <p>{question.question}</p>
                      <div className="question-controls">
                        <FaEdit className="icon" onClick={() => handleEdit(question.id, 'MCQ')} />
                        <FaTrash className="icon" onClick={() => handleDelete(question.id, 'MCQ')} />
                      </div>
                    </div>
                    <div className="options">
                      {[question.option_a, question.option_b, question.option_c, question.option_d].map((option, optionIndex) => (
                        <div className="option" key={optionIndex}>
                          <input
                            className="form-check-input"
                            type="radio"
                            name={`question_${question.id}`}
                            id={`option_${question.id}_${optionIndex}`}
                            value={option}
                            disabled={!isQuizActive}
                          />
                          <label
                            className="form-check-label"
                            htmlFor={`option_${question.id}_${optionIndex}`}
                          >
                            {option}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {questionType === 'TrueFalse' && (
          <div className="tf-section">
            <div className="tf-header">
              <h2>True/False Questions</h2>
            </div>
            <div className="tf-content">
              {tfQuestions.map((question, index) => (
                <div className="tf-card" key={question.id}>
                  <div className="card-header">
                    <h5>{index + 1}</h5>
                  </div>
                  <div className="card-body">
                    <div className="question-header">
                      <p>{question.question}</p>
                      <div className="question-controls">
                        <FaEdit className="icon" onClick={() => handleEdit(question.id, 'TrueFalse')} />
                        <FaTrash className="icon" onClick={() => handleDelete(question.id, 'TrueFalse')} />
                      </div>
                    </div>
                    <div className="options">
                      <div className="option">
                        <input
                          className="form-check-input"
                          type="radio"
                          name={`question_${question.id}`}
                          id={`option_${question.id}_true`}
                          value="true"
                          disabled={!isQuizActive}
                        />
                        <label
                          className="form-check-label"
                          htmlFor={`option_${question.id}_true`}
                        >
                          True
                        </label>
                      </div>
                      <div className="option">
                        <input
                          className="form-check-input"
                          type="radio"
                          name={`question_${question.id}`}
                          id={`option_${question.id}_false`}
                          value="false"
                          disabled={!isQuizActive}
                        />
                        <label
                          className="form-check-label"
                          htmlFor={`option_${question.id}_false`}
                        >
                          False
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {!isQuizActive && (
          <div className="add-question-section">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => questionType === 'MCQ' ? setIsAddQuestionModalOpen(true) : setIsAddTFModalOpen(true)}
            >
              Add {questionType === 'MCQ' ? 'MCQ' : 'True/False'} Question
            </button>
          </div>
        )}
        {isQuizActive && (
          <div className="submit-section">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        )}
      </div>
      {isModalOpen && selectedQuestion && (
        questionType === 'MCQ' ? (
          <EditModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            question={selectedQuestion}
            onSave={(updatedQuestion) => handleSave(updatedQuestion, 'MCQ')}
          />
        ) : (
          <EditTrueFalseModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            question={selectedQuestion}
            onSave={(updatedQuestion) => handleSave(updatedQuestion, 'TrueFalse')}
          />
        )
      )}
      {isAddQuestionModalOpen && (
        <AddQuestionModal
          isOpen={isAddQuestionModalOpen}
          onClose={() => setIsAddQuestionModalOpen(false)}
          onAdd={(newQuestion) => handleAddQuestion(newQuestion, 'MCQ')}
        />
      )}
      {isAddTFModalOpen && (
        <AddTrueFalseModal
          isOpen={isAddTFModalOpen}
          onClose={() => setIsAddTFModalOpen(false)}
          onAdd={(newQuestion) => handleAddQuestion(newQuestion, 'TrueFalse')}
        />
      )}
    </div>
  );
}

export default BuildQuiz;